# 研索 ScholarScope · Atelier Zero

科研竞赛作品，以问题、文献与证据为内容主线。页面从零制作，不复用原页面布局、模板或现有拼贴。

## 视觉绑定
- 背景：Atelier Zero Paper（#efe7d2）
- 表面：Bone（#f7f1de）
- 正文：Ink（#15140f）
- 次级文字：Ink-mute（#5a5448）
- 分隔：Ink 16%
- 强调：Coral（#ed6f5c）
- 展示字体：Inter Tight，中文系统无衬线回退
- 正文字体：Inter，中文系统无衬线回退
- 强调字体：Playfair Display Italic，中文宋体回退
- 等宽字体：JetBrains Mono / SF Mono / Menlo

## 规则
1. 纸张纹理、点状细线与罗马数字形成编辑章节。
2. 用非对称大标题与原创拼贴建立封面。
3. 珊瑚色用于主操作与句末标点；正文保持墨色。
4. 不使用虚构用户规模、效果指标或客户评价。
5. 页面演示固定样例，真实文献检索由关联项目后端提供。

## 六个 OKLch 绑定令牌
```css
--bg: oklch(from var(--paper) l c h);
--surface: oklch(from var(--bone) l c h);
--fg: oklch(from var(--ink) l c h);
--muted: oklch(from var(--ink-mute) l c h);
--border: oklch(from var(--ink) l c h / .2);
--accent: oklch(from var(--coral) l c h);
```

原创封面以“石膏、书页、拱门与知识生长”为提示主题，经 imagegen 生成；展示版仅进行格式压缩。
