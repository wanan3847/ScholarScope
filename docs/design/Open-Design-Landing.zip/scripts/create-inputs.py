import json
from pathlib import Path

def mixed(a,b,c=''):
 return [{'text':a},{'text':b,'em':True},{'text':c},{'text':'.','dot':True}]
d={
'brand':{'name':'研索 ScholarScope','mark':'Ø','meta':{'title':'科研工作台','subtitle':'探索 · 阅读 · 整理'},'filed_under':'科研工具 / 竞赛作品','tagline':'从研究问题，到知识线索','description':'面向科研人员的文献检索、阅读与课题整理工作台。让每一条研究线索，都有可核对的依据。','locale':'zh-CN','edition':'第 01 卷 / 2026 特刊','version':'竞赛演示版','license':'竞赛作品','primary_url':'#research-demo','primary_url_label':'打开工作台','contact_email':'','location':'面向科研人员','coordinates':'研究问题 → 文献证据','year':'2026','year_roman':'MMXXVI','founded':'2026 科研特刊','rails':{'left':'研究问题 · 文献证据 · 知识连接','right':'研索 ScholarScope / 科研特刊 / 2026'},'languages':['简体中文'],'status':'交互演示'},
'nav':[{'label':'为什么研索','href':'#about'},{'label':'研究工具','href':'#capabilities','count':'04'},{'label':'研究路径','href':'#labs','count':'05'},{'label':'使用方法','href':'#method'}],
'hero':{'label':'为研究者，重新整理知识','ix':'第 01 章','headline':mixed('把研究问题，','变成知识线索'),'lead':'从一个值得追问的问题出发。找到相关文献，读懂方法与证据，再将零散的发现，收进自己的研究脉络。','primary':{'label':'开始探索','href':'#research-demo'},'secondary':{'label':'了解研究流程','href':'#method'},'stats':[{'value':'05','label':'检索来源','sub':'多源交叉查找','variant':'solid'},{'value':'04','label':'研究步骤','sub':'从问题到整理'},{'value':'04','label':'导入格式','sub':'接续已有文献'}],'meta':'为科研人员、博士生与科研工程师而作','index':[{'num':'01','label':'提出问题','active':True},{'num':'02','label':'发现文献'},{'num':'03','label':'阅读证据'},{'num':'04','label':'连接知识'}],'annotations':{'tl':'图版 01 / 科研特刊','tr':'知识的生长','bl':'从问题到证据','br':'研索 · 2026'}},
'about':{'label':'研究的起点','ix':'第 02 章','headline':mixed('论文很多，','线索要清楚'),'lead':'真正需要的，往往不是更多搜索结果，而是能够回应研究问题的文献。研索围绕主题、方法、研究对象与明确约束组织检索，让阅读顺序有依据，让研究判断回到原文。','cta_label':'看看如何工作','cta_href':'#method','footer_text':'问题 · 方法 · 对象 · 约束','stamp_top':'研究优先','stamp_bottom':'证据可核对','side_note':'每一次探索，都从具体问题开始。','caption':{'bold':'研究的路径','rest':'从文献出发，连接新的问题。'}},
'capabilities':{'label':'研究工具','ix':'第 03 章','headline':mixed('让知识，','有迹可循'),'lead':'检索、阅读、整理与引用，放在同一条研究路径上。','ribbon':'研究始于提问', 'cards':[
{'num':'01','tag':'发现','icon_svg':'','title':'用研究问题检索','body':'保留主题、方法和年份约束，从多个学术来源寻找文献并合并重复项。','href':'#research-demo'},
{'num':'02','tag':'阅读','icon_svg':'','title':'带着证据阅读','body':'查看摘要、推荐理由与原文证据片段，判断文献是否适合当前课题。','href':'#research-demo'},
{'num':'03','tag':'整理','icon_svg':'','title':'按课题建立文献库','body':'收藏文献、标记已阅，按研究课题整理文件夹，让线索随时可回访。','href':'#research-demo'},
{'num':'04','tag':'衔接','icon_svg':'','title':'接续已有研究资料','body':'导入 BibTeX、RIS、CSV、JSON，导出引用与收藏，接续自己的研究流程。','href':'#research-demo'}]},
'labs':{'label':'研究路径','ix':'第 04 章','headline':mixed('不同问题，','各有路径'),'pills':[{'label':'全部','count':'05','active':True},{'label':'探索','count':'02'},{'label':'深入','count':'02'},{'label':'整理','count':'01'}],'meta':{'ring':'05','bold':'五种研究用途','sub':'按当前任务选择一个入口'},'cards':[
{'badge':'探索','num':'01','year':'问题驱动','title':'进入一个新领域','body':'从核心概念与综述入手，先建立自己的阅读地图。','href':'#research-demo'},
{'badge':'探索','num':'02','year':'主题驱动','title':'寻找课题线索','body':'细化对象与约束，让相关文献回应具体的问题。','href':'#research-demo'},
{'badge':'深入','num':'03','year':'方法驱动','title':'比较研究方法','body':'围绕方法、数据集与代码入口，读懂选择背后的差异。','href':'#research-demo'},
{'badge':'深入','num':'04','year':'证据驱动','title':'追溯关键依据','body':'阅读摘要与证据片段，沿参考文献继续扩展线索。','href':'#research-demo'},
{'badge':'整理','num':'05','year':'课题驱动','title':'沉淀研究资料','body':'收藏、标记、分类，再将文献引用导出到写作流程。','href':'#research-demo'}],'progress':{'total':5,'filled':5},'foot':'选择研究用途，打开对应的示例工作台。'},
'method':{'label':'使用方法','ix':'第 05 章','headline':mixed('从一个问题，','走向理解'),'right':'推荐理由帮助安排阅读顺序，最终判断仍来自你对原文的阅读。','steps':[{'num':'01','title':'描述问题','body':'写明研究主题、方法、对象与年份条件。'},{'num':'02','title':'发现文献','body':'多源检索、合并重复项，继续追踪参考文献。'},{'num':'03','title':'核对证据','body':'结合摘要和原文片段，确定文献的研究用途。'},{'num':'04','title':'整理线索','body':'按课题收藏文献，记录阅读状态并导出引用。'}],'foot_left':'研究，是可以回溯的探索。','foot_right_bold':'研索 ScholarScope','foot_right_rest':'问题 → 文献 → 证据 → 知识'},
'work':{'label':'场景示例','headline':mixed('把研究，','向前推进'),'link_label':'体验示例工作台','link_href':'#research-demo','cards':[{'small_label':'场景 01 / 探索','index':'01','title':'从综述开始，建立阅读地图','body':'围绕检索增强生成，阅读基础方法与领域综述，建立第一批课题文献。','year':'示例场景','tag':'问题 · 文献 · 脉络'},{'small_label':'场景 02 / 整理','index':'02','title':'把读过的文献，留在课题里','body':'按课题收藏文献、标记已阅，并将引用导出到后续写作中。','year':'示例场景','tag':'收藏 · 已阅 · 引用'}]},
 'testimonial':{'label':'研究原则','ix':'第 07 章','quote':mixed('每一条线索，','都值得回到证据'),'author':{'initial':'研','name':'研索的研究原则','title':'以问题组织文献，以证据支持判断'},'partners_text':'项目支持的学术检索来源；页面演示使用固定样例，不代表实时检索结果。','partners':[{'glyph_svg':'','name':n,'role':'检索来源','href':'#research-demo'} for n in ['arXiv','OpenAlex','Crossref','Semantic Scholar','本地索引']],'read_more_label':'阅读演示说明','read_more_href':'#demo-notes'},
'cta':{'label':'开启下一条线索','ix':'第 08 章','headline':mixed('你的下一个发现，','从这里开始'),'lead':'带着问题进入工作台。先体验示例文献的筛选、阅读与收藏，再把清晰的线索带回自己的课题。','primary':{'label':'进入研究演示','href':'#research-demo'},'ribbon':'保持好奇，继续追问'},
'footer':{'brand_description':'面向研究者的文献检索、阅读与资料整理工作台。科研竞赛作品 / 前端交互演示。','columns':[{'title':'认识研索','links':[{'label':'研究理念','href':'#about'},{'label':'核心工具','href':'#capabilities'}]},{'title':'开始研究','links':[{'label':'研究路径','href':'#labs'},{'label':'使用方法','href':'#method'}]},{'title':'体验功能','links':[{'label':'文献检索','href':'#research-demo'},{'label':'收藏与引用','href':'#library-demo'}]},{'title':'作品信息','links':[{'label':'演示说明','href':'#demo-notes'},{'label':'返回封面','href':'#top'}]}],'mega':mixed('保持','好奇')},
'imagery':{'strategy':'generate','assets_path':'./assets/'},
'rules':{}}
for idx,key in enumerate(['about','capabilities','labs','method','work','testimonial','cta'],2):
 d['rules'][key]={'roman':['I','II','III','IV','V','VI','VII','VIII'][idx-1]+'.','meta':[d.get(key,{}).get('label','研究原则'),'·','研索 / 科研特刊'],'pagination':f'{idx:03} / 008'}
Path('inputs.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
Path('brand-spec.md').write_text('''# 研索 ScholarScope · Atelier Zero\n\n科研竞赛作品，以问题、文献与证据为内容主线。页面从零制作，不复用原页面布局、模板或现有拼贴。\n\n## 视觉绑定\n- 背景：Atelier Zero Paper（#efe7d2）\n- 表面：Bone（#f7f1de）\n- 正文：Ink（#15140f）\n- 次级文字：Ink-mute（#5a5448）\n- 分隔：Ink 16%\n- 强调：Coral（#ed6f5c）\n- 展示字体：Inter Tight，中文系统无衬线回退\n- 正文字体：Inter，中文系统无衬线回退\n- 强调字体：Playfair Display Italic，中文宋体回退\n- 等宽字体：JetBrains Mono / SF Mono / Menlo\n\n## 规则\n1. 纸张纹理、点状细线与罗马数字形成编辑章节。\n2. 用非对称大标题与原创拼贴建立封面。\n3. 珊瑚色用于主操作与句末标点；正文保持墨色。\n4. 不使用虚构用户规模、效果指标或客户评价。\n5. 页面演示固定样例，真实文献检索由关联项目后端提供。\n''')
print('品牌简报与内容已落盘')
